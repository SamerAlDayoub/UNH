//**************************************************************************************************
// Name: Samer AlDayoub
// Date: 10/04/2021
// Course: ELEC3371-00
// Description: When pressing PA0 the LEDs on the upper half of port D will turn on and when released the lower half of port D will turn on
//              A counter will ONLY count how many times PA0 is pressed and display the result on port E/ H in binary
//              When pressing PA4 all LEDs on port D will turn on and then off when releasing.
//              After 15 button presses of either PA0 or PA4 the alternating pattern switch between three available patterns.
//              PA5 will manually switch between states and then 15 presses are still requiered to switch states.
//                                PortE/H will keep counting PA0 presses without being reset
//**************************************************************************************************
// assigning variables
    unsigned int counter= 0X0000;         // number of PA0 presses
    int i=0;                                                // LOOPS VARIABLE
    int k=0;                                                // USED TO SHOW THAT PA4 IS PRESSED
//**************************************************************************************************
//MAIN FUNCTION
       void main() {

//**************************************************************************************************
//INITIALIZATIONS
        RCC_APB2ENR |= 1 << 5;  // Enable GPIOD clock - necessary to use GPIOD
        RCC_APB2ENR |= 1 << 6;  // Enable GPIOD clock - necessary to use GPIOE
        RCC_APB2ENR |= 1 << 2;  // Enable GPIOB clock - necessary to use GPIOA
        GPIOD_CRL = 0x33333333;
        GPIOD_CRH = 0x33333333; // Configure GPIOD as output for LEDs
        GPIOE_CRL = 0x33333333;
        GPIOE_CRH = 0x33333333; // Configure GPIOE as output for LEDs
        GPIOA_CRL = 0X44444444;
        GPIOA_CRH = 0X44444444;        // Configure GPIOA as input

        GPIOD_ODR = 0x0000;           // initial value for output port D

//**************************************************************************************************
//MAIN LOOP
       for(;;) {                        // the program will not stop running
            for(i=0; i<15 ; i++) {     //first pattern loop, switching
                 while (!(!(GPIOA_IDR.B0 !=1 ^ GPIOA_IDR.B4 !=1) ^ GPIOA_IDR.B5 !=1)){}         //Some logic waiting until PA0, PA4 or PA5 is pressed
                 k=0; // to check whitch buttom is pressed
                 if (GPIOA_IDR.B0 == 1){
                      GPIOD_ODR = 0xFF00;                 // Toggle LEDs on PORTD
                      counter = 256+counter;
                      GPIOE_ODR = counter;                                        // display PA0 presses on PortE/H
                      }

                  else if (GPIOA_IDR.B4 != 0){ //if PA4 is pressed turn all lights on port D on
                      GPIOD_ODR = 0xFFFF;
                      k=1;                        // to indicate that PA4 was pressed
                         }
                  else {                             // change case
                                                while (GPIOA_IDR.B5 !=0){} // wait until PA5 is released
                                                break;                        // break the first pattern loop and move to the second pattern loop
                    }

                while (GPIOA_IDR.B0 != 0 ^ GPIOA_IDR.B4 != 0){}         // Wait until button is released
                if (k==1){
                      GPIOD_ODR = 0x0000;
                      k=0;
                }
                else{
                     GPIOD_ODR = 0X00FF;
                }
        }
                        for(i=0;i<15;i++) {              //second pattern loop, xoxo
                 while (!(!(GPIOA_IDR.B0 !=1 ^ GPIOA_IDR.B4 !=1) ^ GPIOA_IDR.B5 !=1)){}         // Wait until PA0, PA5 or PA4 is pressed  (XNOR)
                    k=0;
                    if (GPIOA_IDR.B0 == 1){
                      GPIOD_ODR = 38505;                 // Toggle LEDs on PORTD

                    counter = 256+counter;
                    GPIOE_ODR = counter;
                      }

                    else if (GPIOA_IDR.B4 == 1){
                         GPIOD_ODR = 0xFFFF;
                         k=1;
                        }
                     else{

                         while (GPIOA_IDR.B5 !=0){} // wait until PA5 is released
                         break;
                       }
                while (GPIOA_IDR.B0 != 0 ^ GPIOA_IDR.B4 != 0){}         // Wait until button is released
                if (k==1){
                      GPIOD_ODR = 0x0000;
                      k=0;
                }
                else{
                     GPIOD_ODR = 63903;
                }
        }
                        for(i=0; i<15 ; i++) {                 //horiz
                                while (!(!(GPIOA_IDR.B0 !=1 ^ GPIOA_IDR.B4 !=1) ^ GPIOA_IDR.B5 !=1)){}         // Wait until PA0, Pa5 or PA4 is pressed  (XNOR)
                                k=0;
                if (GPIOA_IDR.B0 == 1){
                    GPIOD_ODR = 34952;                 // Toggle LEDs on PORTD
                    counter = 256+counter;
                    GPIOE_ODR = counter;
                      }
                    else if (GPIOA_IDR.B4 == 1){
                         GPIOD_ODR = 0xFFFF;
                         k=1;
                         }
                     else {
                           while (GPIOA_IDR.B5 !=0){} // wait until PA5 is released
                           break;           // switch to the next state
                       }

                while (GPIOA_IDR.B0 != 0 ^ GPIOA_IDR.B4 != 0){}         // Wait until button is released
                if (k==1){
                      GPIOD_ODR = 0x0000;
                      k=0;
                }
                else{
                     GPIOD_ODR = 4369;
                }
        }

      }
}