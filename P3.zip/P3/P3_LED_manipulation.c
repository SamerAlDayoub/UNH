//**************************************************************************************************
// Name: Samer AlDayoub
// Date: 10/11/2021
// Course: ELEC3371-00
// Description: The program will increase the minimum value on port D untill
// the high value with a delay.Delay_us then go back to the small value.
// a0 will make it run slower, a4 and 5 will make it g faster.
// the small value is displayed on port E. by pressing b0 it will change to the big
// b1 will increase samll value
// b2 will increase it
// all buttons need to be held for a while to be active
//**************************************************************************************************
// assigning variables
    unsigned int counter= 0X0000;         // number of PA0 presses
// LOOPS VARIABLEs
    int i=0;
    int k=0;  
    int l = 0;                                              // USED TO SHOW THAT PA4 IS PRESSED
// Values to be compared
   int v1 = 4;
   int t=0;
   int v2 = 9;
   int v=0;

//**************************************************************************************************
void delay();
int increase (int v);
int decrease (int v);
//MAIN FUNCTION
       void main() {

//**************************************************************************************************
//INITIALIZATIONS
        RCC_APB2ENR |= 1 << 5;  // Enable GPIOD clock - necessary to use GPIOD
        RCC_APB2ENR |= 1 << 6;  // Enable GPIOE clock - necessary to use GPIOE
          RCC_APB2ENR |= 1 << 2;  // Enable GPIOB clock - necessary to use GPIOA
        RCC_APB2ENR |= 1 << 3;  // Enable GPIOB clock - necessary to use GPIOB
        GPIOD_CRL = 0x33333333;
        GPIOD_CRH = 0x33333333; // Configure GPIOD as output for LEDs
        GPIOE_CRL = 0x33333333;
        GPIOE_CRH = 0x33333333; // Configure GPIOE as output for LEDs
        GPIOB_CRL = 0X44444444;
        GPIOB_CRH = 0X44444444;        // Configure GPIOB as input
        GPIOA_CRL = 0X44444444;
        GPIOA_CRH = 0X44444444;        // Configure GPIOA as input

        GPIOD_ODR = 0x0000;           // initial value for output port D
//**************************************************************************************************
//MAIN LOOP
       for(;;) {                        // the program will not stop running
             if (v1 > v2) {             // deciding which value is bigger
                    t = v2;             // so we can keep v2 as it is
                   for (i=0 ; i<=v1-v2; ++i){     // output the min value till the max
                   
                     if (GPIOB_IDR.B1 ==1){  // pressing b1 will increase the min value
                        v2= increase (v2);
                        }
                     if (GPIOB_IDR.B2 ==1){  // b2 will dicrease it
                        v2= decrease (v2);
                        }
                     if (GPIOB_IDR.B0 ==1){   // bo is pressed the display value will
                        GPIOE_ODR = 256 * v1; // change to the max on port E.
                        }                     // release will change it back
                     else {
                        GPIOE_ODR = 256*v2;
                        }
                    delay ();                // a5 the fastest

                     GPIOD_ODR = t++;
                    }
                    for (i=0 ; i<=v1-v2; ++i){        // after reaching the max start decrease o min
                                         if (GPIOB_IDR.B1 ==1){
                        v2= increase (v2);
                        }
                     if (GPIOB_IDR.B2 ==1){
                        v2= decrease (v2);
                        }
                        if (GPIOB_IDR.B0 ==1){
                        GPIOE_ODR = 256 * v1;
                        }
                     else {
                        GPIOE_ODR = 256*v2;
                        }
                     delay();
                     GPIOD_ODR = --t;
                    }
             }
             else {                          // in case v2 is min do the same
                   t = v1;
                  for (i=0 ; i<=v2-v1; ++i){

                     if (GPIOB_IDR.B1 ==1){
                        v1= increase (v1);
                        }
                     if (GPIOB_IDR.B2 ==1){
                        v1= decrease (v1);
                        }
                     if (GPIOB_IDR.B0 ==1){
                        GPIOE_ODR = 256 * v2;
                        }
                     else {
                        GPIOE_ODR = 256*v1;
                        }
                    delay ();

                     GPIOD_ODR = t++;
                    }
                    for (i=0 ; i<=v1-v2; ++i){
                                         if (GPIOB_IDR.B1 ==1){
                        v2= increase (v2);
                        }
                     if (GPIOB_IDR.B2 ==1){
                        v2= decrease (v2);
                        }
                        if (GPIOB_IDR.B0 ==1){
                        GPIOE_ODR = 256 * v1;
                        }
                     else {
                        GPIOE_ODR = 256*v1;
                        }
                     delay();
                     GPIOD_ODR = --t;
                    }
                  }

      }
} 

 int increase ( int v) {
    while (GPIOB_IDR.B1 !=0) {}
     v = v +1;
     return v;
    }

  int decrease ( int v) {
    while (GPIOB_IDR.B2 !=0) {}
     v = v -1;
     return v;
    }

void delay(){
                     if (GPIOA_IDR.B0 == 1){
                     delay_ms (300);
                     }
                     else if (GPIOA_IDR.B4 == 1){


                     delay_ms (50);
                     }

                     else if (GPIOA_IDR.B5 == 1){


                     delay_ms (10);
                     }
                     else if (GPIOA_IDR.B3 ==1){
                     delay_ms (400);
                     }
                     else
                     delay_ms(125);

}


//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  /*for(i=0; i<15 ; i++) {     //first pattern loop, switching
                 while (!(!(GPIOA_IDR.B0 !=1 ^ GPIOA_IDR.B4 !=1) ^ GPIOA_IDR.B5 !=1)){}         //Some logic waiting until PA0, PA4 or PA5 is pressed
                 k=0; // to check whitch buttom is pressed
                 if (GPIOA_IDR.B0 == 1){
                      GPIOD_ODR = 0xFF00;                 // Toggle LEDs on PORTD
                      counter = 256+counter;
                      GPIOE_ODR = counter;                                        // display PA0 presses on PortE/H
                      }

                  else if (GPIOA_IDR.B4 != 0){ //if PA4 is pressed turn all lights on port D on
                      GPIOD_ODR = 0xFFFF;
                      k=1;                        // to indicate that PA4 was pressed
                         }
                  else {                             // change case
                                                while (GPIOA_IDR.B5 !=0){} // wait until PA5 is released
                                                break;                        // break the first pattern loop and move to the second pattern loop
                    }

                while (GPIOA_IDR.B0 != 0 ^ GPIOA_IDR.B4 != 0){}         // Wait until button is released
                if (k==1){
                      GPIOD_ODR = 0x0000;
                      k=0;
                }
                else{
                     GPIOD_ODR = 0X00FF;
                }
        }
                        for(i=0;i<15;i++) {              //second pattern loop, xoxo
                 while (!(!(GPIOA_IDR.B0 !=1 ^ GPIOA_IDR.B4 !=1) ^ GPIOA_IDR.B5 !=1)){}         // Wait until PA0, PA5 or PA4 is pressed  (XNOR)
                    k=0;
                    if (GPIOA_IDR.B0 == 1){
                      GPIOD_ODR = 38505;                 // Toggle LEDs on PORTD

                    counter = 256+counter;
                    GPIOE_ODR = counter;
                      }

                    else if (GPIOA_IDR.B4 == 1){
                         GPIOD_ODR = 0xFFFF;
                         k=1;
                        }
                     else{

                         while (GPIOA_IDR.B5 !=0){} // wait until PA5 is released
                         break;
                       }
                while (GPIOA_IDR.B0 != 0 ^ GPIOA_IDR.B4 != 0){}         // Wait until button is released
                if (k==1){
                      GPIOD_ODR = 0x0000;
                      k=0;
                }
                else{
                     GPIOD_ODR = 63903;
                }
        }
                        for(i=0; i<15 ; i++) {                 //horiz
                                while (!(!(GPIOA_IDR.B0 !=1 ^ GPIOA_IDR.B4 !=1) ^ GPIOA_IDR.B5 !=1)){}         // Wait until PA0, Pa5 or PA4 is pressed  (XNOR)
                                k=0;
                if (GPIOA_IDR.B0 == 1){
                    GPIOD_ODR = 34952;                 // Toggle LEDs on PORTD
                    counter = 256+counter;
                    GPIOE_ODR = counter;
                      }
                    else if (GPIOA_IDR.B4 == 1){
                         GPIOD_ODR = 0xFFFF;
                         k=1;
                         }
                     else {
                           while (GPIOA_IDR.B5 !=0){} // wait until PA5 is released
                           break;           // switch to the next state
                       }

                while (GPIOA_IDR.B0 != 0 ^ GPIOA_IDR.B4 != 0){}         // Wait until button is released
                if (k==1){
                      GPIOD_ODR = 0x0000;
                      k=0;
                }
                else{
                     GPIOD_ODR = 4369;
                }
        }
*/