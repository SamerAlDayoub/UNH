//**************************************************************************************************
// Name: Samer AlDayoub
// Date: 10/11/2021
// Course: ELEC3371-00
// Description: This program will change the brightness of LEDs on port A.
//		by adjusting P1 potentiometer using PWM
//**************************************************************************************************

void AdcConfiguration();		// Function to configure ADC on PC0
void PinConfiguration();		// Function to configure GPIO(A-D) as an output
unsigned int getAdcReading();	// Begins conversion and returns 12 bit value
unsigned int adcVal;
int i = 0;
unsigned long int j = 0;        // used to store adcVal

void main() {
	AdcConfiguration();
	PinConfiguration();

	for(;;){
	adcVal = getAdcReading();
		GPIOD_ODR = adcVal;

                j = adcVal + 1;		// +1 to keep it as dim as possible but not off.
                
                for (i=0; i< j; i++){  // based on the value of j, port A leds will
                 GPIOA_ODR = 0xFFFF;   // be on
                }
                  for (i=0; i< 4019-j ; i++){  // the rest until the max value of P1
                 GPIOA_ODR = 0x0000;           // will be off. 4019 so we dont go in the negative values.
                }
	}             // and switching
}

void PinConfiguration(){
	RCC_APB2ENR |= 1 << 5;  	// Enable GPIOD clock
	RCC_APB2ENR |= 1 << 2;  	// Enable GPIOA clock
	GPIOD_CRL = 0x33333333;
	GPIOD_CRH = 0x33333333; 	// Configure GPIOD as output for LEDs
	GPIOA_CRL = 0x33333333;
	GPIOA_CRH = 0x33333333; 	// Configure GPIOA as output for LEDs
	GPIOD_ODR = 0;          	// Initialize all LEDs as OFF
	GPIOA_ODR = 0;				// initialize all LEDs as OFF
}

void AdcConfiguration(){   		// ADC for PC0
	RCC_APB2ENR |= 1 << 4; 		// Enable PORTC clock
	RCC_APB2ENR |= 1 << 9 ;     // Enable ADC1 Clock
	GPIOC_CRL &= ~(0xF << 0);	// Configure PC0 as an Analog Input
	ADC1_SQR1 = (0b0000 << 20);	// 1 conversion
	ADC1_SQR3 = 10;				// Select Channel 10 as only one in conversion sequence
	ADC1_SMPR1 = 0b100;			// Set sample time on channel 10
	ADC1_CR2 |= (0b111 << 17); 	// Set software start as external event for regular group conversion
	ADC1_CR2.ADON = 1;			// Enable ADC1
	delay_ms(10);
}

unsigned int getAdcReading(){
	// Bit 20 is set to start conversion of an external channel, bit 22 starts the conversion
	ADC1_CR2 |= (1 << 22) | (1 << 20);
	while(!(ADC1_SR & 0b10)); 	// Wait until the ADC conversion has ended
	return ADC1_DR;				// Read value from data register. This also clears start bit
}