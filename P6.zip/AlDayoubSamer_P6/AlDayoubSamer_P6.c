//**************************************************************************************************
// Name: Samer AlDayoub
// Date: 11/22/2021
// Course: ELEC3371-00
// Description: This program displays a counter between 0 and 99 seconds on port E. When PA0 is pressed
//				the counnter will pause, when pressed again it will continue.
//				when PB6 is pressed the counter valuse would be sent to the USART teminal.
//**************************************************************************************************
//This program toggles LEDs on PORTE and PORTD if PA0 //or PB6 are pressed respectively on an interrupt basis.
 int counter, MSD, LSD,ch=0;
 int i = 0;
 unsigned long int rcvrd;
//**************************************************************************************************
//INTERRUPT SERVICE ROUTINES
void TIMER2_ISR () iv IVT_INT_TIM2 {          //isr for timer 2
                TIM2_SR.UIF = 0;  			// Reset UIF flag so next interrupt can be recognized when UIF is set
	//	while(!TIM2_SR.UIF){}	  // Wait until timer update flag is set, meaning the count val was reached
		if (i == 0) { // i is the variable that would be set by PA0 to stop the counter
                        counter++;
			GPIOE_ODR= 256*counter;       // display counter on port E high

			if (counter == 99)            // count untill 99 then start again
                           counter = 0;

  }

}

void EXTIPB6() iv IVT_INT_EXTI9_5 ics ICS_AUTO {          //isr to send data to the usart using PB6
EXTI_PR.B6 = 1;     // Clear pending interrupt flag for PB6
MSD = counter/10;
            LSD = counter - (MSD * 10);                   // change ascii code to  number
            while(USART1_SR.TC == 0){}
              USART1_DR = MSD + 48;
           while(USART1_SR.TC == 0){}
            USART1_DR = LSD + 48;
 while(USART1_SR.TC == 0){}

                USART1_DR = 13;
                while(USART1_SR.TC == 0){}

                USART1_DR = 10;
}

void EXTIPA0 () iv IVT_INT_EXTI0 {          //isr to stop the counter
EXTI_PR.B0 = 1;     //Clear pending interrupt flag for PA0
i = ~i;
}

//**************************************************************************************************
//GLOBAL VARIABLES


void PinConfiguration();    // Forward declaration of sub function used for pin configuration
void ExternalIntConfiguration(); // Forward declaration of sub function used for EXTI configuration
void Timer2intConfiguration(); // Forward declaration of sub function used for TIMER1 configuration
void InitializeUSART1();	// Sub function which initializes the registers to enable USART1


//**************************************************************************************************
//MAIN FUNCTION
void main () {
	PinConfiguration();
	ExternalIntConfiguration();
        InitializeUSART1();

	GPIOD_ODR=0X0000;		// Initialize GPIOD LEDS as off
//	GPIOE_ODR=0XF000;		// Initialize GPIOE LEDs as on
        Timer2intConfiguration();
	// You can write your main program from this point on. In this example, the program will
	// execute in an endless loop to keep the program active
	for(;;){
	
		// The peripheral registers can be accessed by half-words (16-bit) or words (32-bit).
		// Per data sheet (pg. 1007) USART1_SR consists of the following:
		// 9   8   7   6   5   4    3   2  1  0
		//CTS LBD TXE TC RXNE IDLE ORE NE FE PE
		while (!((USART1_SR & (1<<5))== 0x20)){} // Check RXNE in USART1 Status Register.
		ch++;										 // while receiver data register is empty, wait
		// You can also check RXNE directly
		// while (!USART1_SR.RXNE = 1) {}    //while receiver data register is empty wait

		// When data becomes available, we can store it on the CPU in a variable. Data is put into
		// the USART data register USART1_DR (pg. 1010)
		rcvrd = USART1_DR;    //read data from receiver data register
		//while transmitter data register is not empty wait
		 while (! (USART1_SR & (1<<7)) == 0x80) {}
		 // If we want to send data out via USART, we use the same data register
		 USART1_DR = rcvrd;
                 GPIOD_ODR = ch;

}

        }
//**************************************************************************************************
//SUB FUNCTIONS
void PinConfiguration() {
	GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_ALL);
	GPIO_Digital_Output(&GPIOE_BASE, _GPIO_PINMASK_ALL);
	GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_0);
	GPIO_Digital_Input(&GPIOB_BASE, _GPIO_PINMASK_6);
}

void ExternalIntConfiguration(){
	RCC_APB2ENR.AFIOEN = 1;     // Enable clock for alternate pin function
	AFIO_EXTICR1  = 0x00000000; // PA0 as External interrupt
	AFIO_EXTICR2 |= 0x00000100; // PB6 as External interrupt
	EXTI_RTSR |= 0x00000041;    // Set interrupt on rising edge for PA0 and PB6
	EXTI_IMR |= 0x00000041;     // Interrupt on PA0 and PB6 are non-maskable
	NVIC_ISER0 |= 1<<6;         // Enable NVIC interrupt for EXTI line zero (PA0)
                                // with position 6 in NVIC table
	NVIC_ISER0.B23=1;// |= 1<<23;        // Enable NVIC interrupt for EXTI9_% (PB6) position 23 in NVIC table
}
void InitializeUSART1(){ // Sub function which initializes the registers to enable USART1
	RCC_APB2ENR |= 1;                 // Enable clock for Alt. Function. USART1 uses AF for PA9/PA10
	AFIO_MAPR=0X0F000000;             // Do not mask PA9 and PA10 (becaue we are using for USART)
	RCC_APB2ENR |= 1<<2;              // Enable clock for GPIOA
	GPIOA_CRH &= ~(0xFF << 4);        // Clear PA9, PA10
	GPIOA_CRH |= (0x0B << 4);         // USART1 Tx (PA9) output push-pull
	GPIOA_CRH |= (0x04 << 8);         // USART1 Rx (PA10) input floating
	RCC_APB2ENR |= 1<<14;             // enable clock for USART1
	USART1_BRR=0X00000506;            // Set baud rate to 56000
	// Per data sheet (pg. 1010) USART1_CR1 consists of the following:
	//13 12   11  10  9    8     7    6      5      4  3  2   1   0
	//UE  M WAKE PCE PS PEIE TXEIE TCIE RXNEIE IDLEIE TE RE RWU SBK
	//rw rw  rw   rw rw   rw    rw   rw     rw     rw rw rw  rw  rw
	USART1_CR1 &= ~(1<<12);          // Force 8 data bits. M bit is set to 0.
	USART1_CR2 &= ~(3<<12);          // Force 1 stop bit
	USART1_CR3 &= ~(3<<8);           // Force no flow control and no DMA for USART1
	USART1_CR1 &= ~(3<<9);           // Force no parity and no parity control
	USART1_CR1 |= 3<<2;              // RX, TX enable
	//The following two instructions can also be used to enable RX and TX manually
	//USART1_CR1.TE=1; //TX enable
	//USART1_CR1.RE=1; //RX enable
	USART1_CR1 |= 1<<13;            // USART1 enable. This is done after configuration is complete
	Delay_ms(100);                  // Wait for USART to complete configuration and enable. This is

}
void Timer2intConfiguration(){
        RCC_APB1ENR |= 1;   // Enable TIMER2 clock. RCC: Clock Configuration Register
                                                                // Different clocks may use different registers.
                                                                // Ex. TIMER4 uses RCC_APB1ENR
        TIM2_CR1 = 0x0000;  // Disable timer until configuration is complete
                                                // If reset value of RCC_CFGR is used, then the 8MHz clock will
                                                // be the clock source for timer
        TIM2_PSC = 7999;    // Clock to TIMx_CNT = 72000000 (clock applied to prescaler register) /
                                            //                     7999 (Value in TIMx_PSC) + 1) = 9000
        TIM2_ARR = 9000;        // Reload timer count register with this value when count register resets
        NVIC_ISER0.B28=1;// |= 1<<29;	// Enable global interrupt for TIMER2 in NVIC
							// Interrupt set enable register 0. Position of this interrupt in vector
							// table is 29, so set the corresponding bit in interrupt service enable
							// register 0. This is a 32 bit register. ISER1 is used for interrupt
	TIM2_DIER.UIE = 1;  	// Update interrupt enable
							// numbers greater than 31.
       TIM2_CR1 = 0x0001;         // Enable TIMER1
}

									// not always necessary, but good practice.