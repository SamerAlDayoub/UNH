//**************************************************************************************************
// Name: Samer AlDayoub
// Date: 11/22/2021
// Course: ELEC3371-00
// Description: This program will blink PD0 on a frequency set using a timer interrupt.A0 is pressedineer
//				the frequency is set using time delay in the ISR to turn the led on and off
//				the higher the delay is the lower the frequency
//**************************************************************************************************


//**************************************************************************************************
//INTERRUPT SERVICE ROUTINES
void TIMER2_ISR () iv IVT_INT_TIM2 {        //isr for timer 2
                TIM2_SR.UIF = 0;  			// Reset UIF flag so next interrupt can be recognized when UIF is set
	//	while(!TIM2_SR.UIF){}	  // Wait until timer update flag is set, meaning the count val was reached
				GPIOD_ODR.B0 = 1;             // turn the led
				delay_ms(30);
				GPIOD_ODR.B0 = 0;
				delay_ms(30);
}

void PinConfiguration();    // Forward declaration of sub function used for pin configuration
void Timer2intConfiguration(); // Forward declaration of sub function used for TIMER1 configuration
//**************************************************************************************************
//MAIN FUNCTION
void main () {
	PinConfiguration();
//	GPIOE_ODR=0XF000;		// Initialize GPIOE LEDs as on
        Timer2intConfiguration();
	// You can write your main program from this point on. In this example, the program will
	// execute in an endless loop to keep the program active
	for(;;){

}

        }
//**************************************************************************************************
//SUB FUNCTIONS
void PinConfiguration() {
	GPIO_Digital_Output(&GPIOD_BASE, _GPIO_PINMASK_ALL);
	GPIO_Digital_Output(&GPIOE_BASE, _GPIO_PINMASK_ALL);
	GPIO_Digital_Input(&GPIOA_BASE, _GPIO_PINMASK_0);
	GPIO_Digital_Input(&GPIOB_BASE, _GPIO_PINMASK_6);
}

void Timer2intConfiguration(){
        RCC_APB1ENR |= 1;   // Enable TIMER2 clock. RCC: Clock Configuration Register
                                                                // Different clocks may use different registers.
                                                                // Ex. TIMER4 uses RCC_APB1ENR
        TIM2_CR1 = 0x0000;  // Disable timer until configuration is complete
                                                // If reset value of RCC_CFGR is used, then the 8MHz clock will
                                                // be the clock source for timer
        TIM2_PSC = 7999;    // Clock to TIMx_CNT = 72000000 (clock applied to prescaler register) /
                                            //                     7999 (Value in TIMx_PSC) + 1) = 9000
        TIM2_ARR = 10;        // Reload timer count register with this value when count register resets
        NVIC_ISER0.B28=1;// |= 1<<29;	// Enable global interrupt for TIMER2 in NVIC
							// Interrupt set enable register 0. Position of this interrupt in vector
							// table is 29, so set the corresponding bit in interrupt service enable
							// register 0. This is a 32 bit register. ISER1 is used for interrupt
	TIM2_DIER.UIE = 1;  	// Update interrupt enable
							// numbers greater than 31.
       TIM2_CR1 = 0x0001;         // Enable TIMER1
}

									